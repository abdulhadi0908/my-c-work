#include<stdio.h>
int main()
{
    int x=10, y=20;
    if(x>y)
    {
        printf("x is greater");
        printf("/n is greater");
    }
    else
    {
        printf("y is greater");
        printf("/n end");
    }
}